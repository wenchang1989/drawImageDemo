//
//  CWCMyDrawer.h
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CWCMyDrawer : UIView
/**
 *  线宽
 */
@property (nonatomic, assign) CGFloat width;
/**
 *  线的颜色
 */
@property (nonatomic, strong) UIColor *lineColer;
//
/**
 *  撤销的线条数组
 */
@property (nonatomic, strong)NSMutableArray *canceledLines;

/**
 *  线条数组
 */
@property (nonatomic, strong)NSMutableArray *lines;
/**
 *  清屏
 */
- (void)clearScreen;

/**
 *  撤销
 */
- (void)undo;
/**
 *  恢复
 */
- (void)redo;

@end
