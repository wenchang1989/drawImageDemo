//
//  CWCResultView.h
//  CWCDrawCard
//
//  Created by CWC on 16/1/13.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CWCResultView : UIView

- (void)addWithFrame:(CGRect)frame andTitle:(NSString *)title andMessage:(NSString *)message;

@end
