//
//  CWCBezierPath.h
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CWCBezierPath : UIBezierPath

/**
 *  画线载体
 *
 *  @param width      线条宽度
 *  @param startPoint 开始位置
 *
 *  @return 线条
 */
+ (instancetype)bezierPathWithLineWidth:(CGFloat)width startPoint:(CGPoint)startPoint;



@end
