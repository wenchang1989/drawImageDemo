//
//  CWCResultView.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/13.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "CWCResultView.h"

#define SCREEN_SIZE [UIScreen mainScreen].bounds.size
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

@interface CWCResultView ()



@end

@implementation CWCResultView

- (void)addWithFrame:(CGRect)frame andTitle:(NSString *)title andMessage:(NSString *)message{

    self.frame = frame;
    
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = 6;
    
    self.backgroundColor = [UIColor whiteColor];
    [self addLabelWithRect:CGRectMake(0, 0, frame.size.width, frame.size.height/3) andTitle:title andFont:16 andAligent:NSTextAlignmentCenter andIsTitle:YES];
    [self addLabelWithRect:CGRectMake(0, frame.size.height/3, frame.size.width, frame.size.height/3) andTitle:message andFont:14 andAligent:NSTextAlignmentCenter andIsTitle:NO];
    
    [self addButtonWithRect:CGRectMake(0, frame.size.height-frame.size.height/3, frame.size.width, frame.size.height/3)];
    
}

- (void)addLabelWithRect:(CGRect)rect andTitle:(NSString *)title andFont:(CGFloat)font andAligent:(NSTextAlignment)alignment andIsTitle:(BOOL)isTitle{

    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.backgroundColor = [UIColor clearColor];
    label.text = title;
    label.font = [UIFont systemFontOfSize:font];
    if (isTitle) {
        label.font = [UIFont boldSystemFontOfSize:font];
    }else{
    
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(label.frame)-0.5, SCREEN_SIZE.width, 0.5)];
        view.backgroundColor = [UIColor lightGrayColor];
        [label addSubview:view];
        
    }
    label.textAlignment = alignment;
    
    label.layer.masksToBounds = YES;
    label.layer.cornerRadius = 6;
    
    [self addSubview:label];
    
}
- (void)addButtonWithRect:(CGRect)rect{

    UIButton *button = [[UIButton alloc] initWithFrame:rect];
    [button setTitle:@"确定" forState:UIControlStateNormal];
    [button setTitleColor:RGBACOLOR(79, 151, 239, 1) forState:UIControlStateNormal];
    
    [button setBackgroundImage:[self imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
    [button setBackgroundImage:[self imageWithColor:[UIColor lightGrayColor]] forState:UIControlStateHighlighted];
    
    button.layer.masksToBounds = YES;
    button.layer.cornerRadius = 6;
    
    [button addTarget:self action:@selector(removeFromSup:) forControlEvents:UIControlEventTouchUpInside];
    
    [self addSubview:button];
}

- (void)removeFromSup:(UIButton *)sender{

    [self removeFromSuperview];
    
}

- (UIImage *)imageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}


@end
