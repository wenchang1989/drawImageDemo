//
//  CWCMyDrawer.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "CWCMyDrawer.h"
#import "CWCBezierPath.h"

@interface CWCMyDrawer ()

@property (nonatomic, strong)CWCBezierPath *path;
@property (nonatomic, strong)CAShapeLayer *shapeLayer;

@end


@implementation CWCMyDrawer



- (void)setWidth:(CGFloat)width{

    _width = width;
   
}


- (NSMutableArray *)lines{

    if (_lines == nil) {
        _lines = [NSMutableArray array];
        
    }
    return _lines;
}

- (NSMutableArray *)canceledLines{

    if (_canceledLines == nil) {
        _canceledLines = [NSMutableArray array];
    }
    return _canceledLines;
}

- (instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        _width = 3;
        self.lineColer = [UIColor blackColor];
    }
    return self;
}

/**
 *  根据touches集合获取对应的触摸点
 *
 *  @param touches 触摸集合
 *
 *  @return 触摸点
 */
- (CGPoint)pointWithTouches:(NSSet *)touches{

    UITouch *touch = [touches anyObject];
    return [touch locationInView:self];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    
    
    CGPoint startPoint = [self pointWithTouches:touches];
    
    if ([event allTouches].count == 1) {
        CWCBezierPath *path = [CWCBezierPath bezierPathWithLineWidth:_width startPoint:startPoint];
        self.path = path;
        
        CAShapeLayer *shapeLayer = [CAShapeLayer layer];
        shapeLayer.path = path.CGPath;
        shapeLayer.backgroundColor = [UIColor clearColor].CGColor;
        shapeLayer.fillColor = [UIColor clearColor].CGColor;
        shapeLayer.lineCap = kCALineCapRound;
        shapeLayer.lineJoin = kCALineCapRound;
        shapeLayer.strokeColor = self.lineColer.CGColor;
        shapeLayer.lineWidth = path.lineWidth;
        
        [self.layer addSublayer:shapeLayer];
        self.shapeLayer = shapeLayer;
        
        [[self mutableArrayValueForKey:@"canceledLines"] removeAllObjects];
        [[self mutableArrayValueForKey:@"lines"] addObject:self.shapeLayer];
        
    }
    
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    //获取移动点
    CGPoint movePoint = [self pointWithTouches:touches];
    if ([event allTouches].count > 1) {
        [self.superview touchesMoved:touches withEvent:event];
    }else if ([event allTouches].count == 1){
    
        [_path addLineToPoint:movePoint];
        
        _shapeLayer.path = _path.CGPath;
        
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    if ([event allTouches].count > 1) {
        [self.superview touchesEnded:touches withEvent:event];
    }
    
}
/**
 *  画线
 */
- (void)drawLine{

    [self.layer addSublayer:self.lines.lastObject];
    
}
/**
 *  清屏
 */
- (void)clearScreen{

    //画过图才清屏，否则不做任何操作
    if (self.lines.count) {
        [self.lines makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
        [[self mutableArrayValueForKey:@"lines"] removeAllObjects];
        [[self mutableArrayValueForKey:@"canceledLines"] removeAllObjects];
    }
    
}

/**
 *  恢复
 */

- (void)redo{

    //当前没有做过撤销操作，就不用恢复了
    if (self.canceledLines.count) {
        [[self mutableArrayValueForKey:@"lines"] addObject:self.canceledLines.lastObject];
        [[self mutableArrayValueForKey:@"canceledLines"] removeLastObject];
        [self drawLine];
    }
    
}
/**
 *  撤销
 */
- (void)undo{

    if (self.lines.count) {
        [[self mutableArrayValueForKey:@"canceledLines"] addObject:self.lines.lastObject];
        [self.lines.lastObject removeFromSuperlayer];
        [[self mutableArrayValueForKey:@"lines"] removeLastObject];
        
    }
    
}



@end
