//
//  ViewController.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "ViewController.h"
#import "CWCDrawBoarderView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    UITextField *label = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 120, 30)];
//    
//    label.text = @"hhdadhahdhasfhdshfhsdhfshdghfdghdhghdfhghdfghd";
//    
//    CGSize size = [label sizeThatFits:label.bounds.size];
//    
//    NSLog(@"%@",NSStringFromCGSize(size));

    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self addButton];
    
    
}


- (void)addButton{

    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 80, 30)];
    
    [button setTitle:@"开始画图" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor yellowColor] forState:UIControlStateHighlighted];
    
    button.tag = 10000;
    
    button.center = self.view.center;
    
    button.layer.masksToBounds = YES;
    button.layer.cornerRadius = 4;
    
    button.layer.borderWidth = 1.5;
    button.layer.borderColor = [UIColor blueColor].CGColor;
    
    [button addTarget:self action:@selector(startDraw:) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:button];
    
}
- (void)startDraw:(UIButton *)sender{

    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
    CWCDrawBoarderView *boardView = [[CWCDrawBoarderView alloc] initWithFrame:self.view.bounds];
    
    boardView.myViewController = self;
    
    [boardView show];
    
    [sender setHidden:YES];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
