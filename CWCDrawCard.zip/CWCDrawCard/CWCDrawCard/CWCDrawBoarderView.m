//
//  CWCDrawBoarderView.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "CWCDrawBoarderView.h"
#import "CWCMyDrawer.h"
#import "CWCScrollView.h"
#import "CWCResultView.h"

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define SCREEN_SIZE [UIScreen mainScreen].bounds.size

@interface CWCDrawBoarderView ()<UITextFieldDelegate>
/**
 *  工具条的view
 */
@property (nonatomic, strong) UIView *toolView;
/**
 *  画板view
 */
@property (nonatomic, strong) CWCScrollView *boardView;
/**
 *  按钮图片
 */
@property (nonatomic, strong) NSArray *buttonImgNames;
/**
 *  按钮不可用图片
 */
@property (nonatomic, strong) NSArray *btnEnableImgNames;

@property (nonatomic, strong) CWCMyDrawer *myDrawer;

@property (nonatomic, strong) UIButton *delAllBtn;//删除
@property (nonatomic, strong) UIButton *fwBtn;//上一步
@property (nonatomic, strong) UIButton *ntbtn;//下一步

/**
 *  将图保存本地
 */
@property (nonatomic, strong) UIButton *saveButton;

@end

@implementation CWCDrawBoarderView


- (CWCMyDrawer *)myDrawer{

    if (_myDrawer == nil) {
        _myDrawer = [[CWCMyDrawer alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width*5, SCREEN_SIZE.height * 2)];
        _myDrawer.layer.backgroundColor = [UIColor clearColor].CGColor;
    }
    
    return _myDrawer;
}

- (NSArray *)btnEnableImgNames{

    if (_btnEnableImgNames == nil) {
        _btnEnableImgNames = @[@"close_draft_enable",@"delete_draft_enable",@"undo_draft_enable",@"redo_draft_enable"];
    }
    
    return _btnEnableImgNames;
}


- (NSArray *)buttonImgNames{

    if (_buttonImgNames == nil) {
        _buttonImgNames = @[@"close_draft",@"delete_draft",@"undo_draft",@"redo_draft"];
    }
    
    return _buttonImgNames;
    
}

- (instancetype)initWithFrame:(CGRect)frame{

    frame = CGRectMake(0, SCREEN_SIZE.height, SCREEN_SIZE.width, SCREEN_SIZE.height);
    self = [super initWithFrame:frame];
    if (self) {
        //顶部工具条
        UIView *toolView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_SIZE.width, 64)];
        toolView.backgroundColor = RGBACOLOR(79, 151, 239, 1);
        [self addSubview:toolView];
        self.toolView = toolView;
        
        //顶部按钮
        CGFloat btnW = toolView.bounds.size.width/4.0f;
        CGFloat btnH = toolView.bounds.size.height - 20;
        
        for (NSInteger i = 0; i < 4; i ++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(i * btnW, 20, btnW, btnH);
            
            [btn setImage:[UIImage imageNamed:self.buttonImgNames[i]] forState:UIControlStateNormal];
            [btn setImage:[UIImage imageNamed:self.buttonImgNames[i]] forState:UIControlStateSelected];
            
            [btn setImage:[UIImage imageNamed:self.btnEnableImgNames[i]] forState:UIControlStateDisabled];
            
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            
            btn.tag = i + 100;
            
            [self.toolView addSubview:btn];
            
            if (i > 0) {
                [btn setEnabled:NO];
            }
        }
        
        self.delAllBtn = (UIButton *)[self.toolView viewWithTag:101];
        self.fwBtn = (UIButton *)[self.toolView viewWithTag:102];
        self.ntbtn = (UIButton *)[self.toolView viewWithTag:103];
        
        [self.myDrawer addObserver:self forKeyPath:@"lines" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:nil];
        [self.myDrawer addObserver:self forKeyPath:@"canceledLines" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:nil];
        
        
        //颜色和线条宽度
        [self addTextFieldIsColer:NO andRect:CGRectMake(40, CGRectGetMaxY(self.toolView.frame), 80, 30)];
        [self addTextFieldIsColer:YES andRect:CGRectMake(SCREEN_SIZE.width-120, CGRectGetMaxY(self.toolView.frame), 80, 30)];
        
//        [NSNotification ] 
        
        //保存本地按钮
        [self addSaveButton];
        
        //画板view
        CWCScrollView *boardView = [[CWCScrollView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(toolView.frame) + 30, SCREEN_SIZE.width, SCREEN_SIZE.height-CGRectGetMaxY(toolView.frame) - 30)];
        
        boardView.layer.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.15].CGColor;
        [boardView setUserInteractionEnabled:YES];
        [boardView setScrollEnabled:YES];
        [boardView setMultipleTouchEnabled:YES];
        [boardView addSubview:self.myDrawer];
        boardView.contentSize = self.myDrawer.frame.size;
        [boardView setDelaysContentTouches:NO];
        [boardView setCanCancelContentTouches:NO];
        
        [self insertSubview:boardView belowSubview:toolView];
        
        self.boardView = boardView;
        
        
        [[UIApplication sharedApplication].keyWindow addSubview:self];
        
    }
    
    
    return self;
}
#pragma mark UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    NSString *newString = [NSString stringWithFormat:@"%@%@",textField.text,string];
    NSLog(@"=========%@",newString);
    
    if (textField.tag == 123) {
        self.myDrawer.width = [newString floatValue];
    }else{
        
        if ([newString integerValue] > 7) {
            self.myDrawer.lineColer = [UIColor blackColor];
            return YES;
        }
        
        switch ([textField.text integerValue]) {
            case 1:
                self.myDrawer.lineColer = [UIColor blackColor];
                break;
            case 2:
                self.myDrawer.lineColer = [UIColor blueColor];
                break;
            case 3:
                self.myDrawer.lineColer = [UIColor grayColor];
                break;
            case 4:
                self.myDrawer.lineColer = [UIColor greenColor];
                break;
            case 5:
                self.myDrawer.lineColer = [UIColor orangeColor];
                break;
            case 6:
                self.myDrawer.lineColer = [UIColor cyanColor];
                break;
            case 7:
                self.myDrawer.lineColer = [UIColor redColor];
                break;
                
            default:
                break;
        }
        
        
    }
    
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{

    /*
    if (textField.tag == 123) {
        self.myDrawer.width = [textField.text floatValue];
    }else{
    
        if ([textField.text integerValue] > 7) {
            self.myDrawer.lineColer = [UIColor blackColor];
            return;
        }
        
        switch ([textField.text integerValue]) {
            case 1:
                self.myDrawer.lineColer = [UIColor blackColor];
                break;
            case 2:
                self.myDrawer.lineColer = [UIColor blueColor];
                break;
            case 3:
                self.myDrawer.lineColer = [UIColor grayColor];
                break;
            case 4:
                self.myDrawer.lineColer = [UIColor greenColor];
                break;
            case 5:
                self.myDrawer.lineColer = [UIColor orangeColor];
                break;
            case 6:
                self.myDrawer.lineColer = [UIColor cyanColor];
                break;
            case 7:
                self.myDrawer.lineColer = [UIColor redColor];
                break;
                
            default:
                break;
        }
        
        
    }
    */
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    [textField resignFirstResponder];
    
    return YES;
}

- (void)addTextFieldIsColer:(BOOL)isColer andRect:(CGRect)rect{

    UITextField *textField = [[UITextField alloc] initWithFrame:rect];
    
    textField.textAlignment = NSTextAlignmentCenter;
    textField.layer.masksToBounds = YES;
    textField.layer.cornerRadius = 4;
    textField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    textField.layer.borderWidth = 1.5f;
    textField.placeholder = @"线条宽度3";
    textField.tag = 123;
    if (isColer) {
        textField.placeholder = @"颜色1-7";
        textField.tag = 321;
    }
    
    
    textField.delegate = self;
    
    [self addSubview:textField];
}

- (void)addSaveButton{

    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 80, 30)];
    button.center = CGPointMake(SCREEN_SIZE.width/2, CGRectGetMaxY(self.toolView.frame)+ 15);
    [button setTitle:@"保存本地" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor whiteColor];
    [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
    
    button.layer.masksToBounds = YES;
    button.layer.cornerRadius = 4;
    button.layer.borderColor = [UIColor lightGrayColor].CGColor;
    button.layer.borderWidth = 1.5;
    
    [button addTarget:self action:@selector(saveImage:) forControlEvents:UIControlEventTouchUpInside];
    
    button.enabled = NO;
    
    self.saveButton = button;
    
    [self addSubview:button];
    
}
#pragma mark=保存图片到本地
- (void)saveImage:(UIButton *)sender{

    UIGraphicsBeginImageContext(self.boardView.bounds.size);
    [self.boardView.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *saveImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    UIImageWriteToSavedPhotosAlbum(saveImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    
}

#pragma mark=保存结果
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)errer contextInfo:(void *)contextInfo{

    NSString *resultMessage;
    if (errer) {
        resultMessage = @"保存失败，请重试！";
    }else{
    
        resultMessage = @"保存图片成功！";
        
    }
    
    CWCResultView *resuleView = [[CWCResultView alloc] init];
    [resuleView addWithFrame:CGRectMake(60, 0, SCREEN_SIZE.width-120, 120) andTitle:@"保存结果" andMessage:resultMessage];
    resuleView.center = self.center;
    
    [[UIApplication sharedApplication].keyWindow addSubview:resuleView];
    
//    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"保存结果" message:resultMessage preferredStyle:UIAlertControllerStyleAlert];
//    
//    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        
//    }];
//    
//    [alertVC addAction:action];
//    
//    [self.myViewController presentViewController:alertVC animated:YES completion:nil];
    
}

- (void)show{

    self.myDrawer.lines = [NSMutableArray arrayWithArray:self.linesInfo];
    for (CALayer *layer in self.myDrawer.lines) {
        [self.myDrawer.layer addSublayer:layer];
    }
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.frame = CGRectMake(0, 0, SCREEN_SIZE.width, SCREEN_SIZE.height);
    } completion:nil];
}


- (void)dismiss{

    UIButton *button = (UIButton *)[self.myViewController.view viewWithTag:10000];
    [button setHidden:NO];
    
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    
    
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        CGRect frame = self.frame;
        frame.origin.y += frame.size.height;
        self.frame = frame;
    } completion:^(BOOL finished) {
        if (finished) {
            [self removeFromSuperview];
            
            [self.myDrawer removeObserver:self forKeyPath:@"canceledLines"];
            [self.myDrawer removeObserver:self forKeyPath:@"lines"];
            
        }
    }];
    
}


- (void)btnClick:(UIButton *)sender{

    switch (sender.tag) {
        case 100:
            [self dismiss];
            break;
            case 101:
            [self.myDrawer clearScreen];
            break;
            case 102:
            [self.myDrawer undo];
            break;
            case 103:
            [self.myDrawer redo];
            break;
        default:
            break;
    }
    
}

#pragma mark=观察者
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{

    if ([keyPath isEqualToString:@"lines"]) {
        NSMutableArray *lines = [self.myDrawer mutableArrayValueForKey:@"lines"];
        if (lines.count) {
            self.saveButton.enabled = YES;
            [self.saveButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            self.saveButton.layer.borderColor = [UIColor blueColor].CGColor;
            [self.delAllBtn setEnabled:YES];
            [self.fwBtn setEnabled:YES];
        }else{
        
            self.saveButton.enabled = NO;
            [self.saveButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            self.saveButton.layer.borderColor = [UIColor lightGrayColor].CGColor;
            [self.delAllBtn setEnabled:NO];
            [self.fwBtn setEnabled:NO];
            
        }
    }else if ([keyPath isEqualToString:@"canceledLines"]){
    
        NSMutableArray *canceledLines = [self.myDrawer mutableArrayValueForKey:@"canceledLines"];
        if (canceledLines.count) {
            [self.ntbtn setEnabled:YES];
        }else{
        
            [self.ntbtn setEnabled:NO];
            
        }
        
    }
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self endEditing:YES];
    
}

@end
