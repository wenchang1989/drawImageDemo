//
//  CWCScrollView.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "CWCScrollView.h"

@implementation CWCScrollView

- (BOOL)touchesShouldBegin:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view{

    if ([event allTouches].count == 1) {
        return YES;
    }
    
    return NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
