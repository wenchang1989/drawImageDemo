//
//  CWCBezierPath.m
//  CWCDrawCard
//
//  Created by CWC on 16/1/8.
//  Copyright © 2016年 SouFun. All rights reserved.
//

#import "CWCBezierPath.h"

@implementation CWCBezierPath

+ (instancetype)bezierPathWithLineWidth:(CGFloat)width startPoint:(CGPoint)startPoint{

    CWCBezierPath *path = [[CWCBezierPath alloc] init];
    
    path.lineWidth = width;
    /**
     *  线条拐角
     */
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineCapRound;//终点处理
    [path moveToPoint:startPoint];
    
    return path;
    
}

@end
